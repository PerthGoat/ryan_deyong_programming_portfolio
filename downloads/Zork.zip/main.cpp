#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <cstdio>
#include <stdexcept>
#include "datastructures.h"
#include "xmlparse.h"

using namespace std;

int main(void) {
    vector<room> rooms;
    
    // looks for rooms.xml which holds ALL of our room and ADVENTURE data
    FILE * file;
    file = fopen("rooms.xml", "r");
    
    // parses the xml file into the rooms vector, note: CLOSES THE FILE HANDLE ON ITS OWN
    parseFile(file, rooms);
    
    // creates a player object at position 0, 0
    player p(1, -1, rooms);
    
    /*int s = -1;
    
    // sets up the game
    while(!(s == 0 || s == 1)) {
        printf("ZORK\n");
        printf("0. New Game\n");
        printf("1. Continue game\n");
        printf(">");
        scanf("%d", &s);
    }
    
    printf("\n");*/
    
    char cmd[256];
    
    // game loop
    // note: commands are all hard-coded
    bool exit = false;
    while(!exit) {
        p.getCurrentRoom().printDescription();
        
        // ending condition
        if(p.getCurrentRoom().getEnd() == 1) {
            printf("%s\n", p.getCurrentRoom().getEndText().c_str());
            exit = true;
            break;
        }
        
        printf(">");
        scanf("%s", cmd);
        // if the exit command
        if(strcmp(cmd, "objects") == 0) {
            p.getCurrentRoom().printObjectsOnFloor();
        }
        else if(strcmp(cmd, "list") == 0) { // prints out all of the hard-coded commands
            printf("Commands (case sensitive):\n");
            printf("objects -- displays objects on the floor\n");
            printf("move -- opens up move interface\n");
            printf("pick -- pickup an object from the floor\n");
            printf("inv -- list inventory contents\n");
            printf("use -- use an item in your inventory\n");
            printf("exit -- exits the game\n");
        }
        else if(strcmp(cmd, "inv") == 0) { // prints out the inventory
            p.printInventory();
        }
        else if(strcmp(cmd, "move") == 0) {
            // TODO: Write this so that the commands north, east, south, and west correspond to movement
            //printf("(n, e, s, w):: ");
            scanf("%s", cmd);
            if(strcmp(cmd, "n") == 0) {
                //printf("NORTH\n");
                p.move(2);
            } else if(strcmp(cmd, "e") == 0) {
                //printf("EAST\n");
                p.move(1);
            } else if(strcmp(cmd, "s") == 0) {
                //printf("SOUTH\n");
                p.move(0);
            } else if(strcmp(cmd, "w") == 0) {
                //printf("WEST\n");
                p.move(3);
            } else {
                printf("Invalid direction! n, s, e, or w?\n");
            }
        }
        else if(strcmp(cmd, "pick") == 0) {
            //printf("object to pick: ");
            scanf("%s", cmd);
            
            if(p.getCurrentRoom().lookup(cmd, 0) != -1) {
                printf("%s\n", p.getCurrentRoom().readObjectDescription(p.getCurrentRoom().lookup(cmd, 0)).c_str());
                p.pickupObject(cmd);
            } else {
                printf("Invalid object.\n");
            }
        }
        else if(strcmp(cmd, "use") == 0) {
            scanf("%s", cmd);
            
            if(p.lookup(cmd) != -1) {
                if(p.getObjectName(cmd).find(":FOOD") != string::npos) {
                    printf("You thoroughly enjoyed the food.\n");
                    p.removeObjectFromInventory(p.lookup(cmd));
                } else {
                    printf("I can't use this.\n");
                }
            } else {
                printf("You don't have that!\n");
            }
            
        }
        else if(strcmp(cmd, "exit") == 0) {
            exit = true;
        }
        else {
            printf("Invalid command: %s\n", cmd);
            printf("Type 'list' to show available commands\n");
        }
        printf("\n");
    }
    
    printf("Goodbye.\n");
    
    //test.printCurrentRoom();
    //test.move(2);
    //test.printCurrentRoom();
    
    
    
    //test.printCurrentRoom();
    
    
    //cout << (rooms[0].lookup("Scott", 0)) << endl;
    //vector<string> str = {"Hello", "Scott", "Manley"};
    //room r(str);
    //cout << r.lookup("Bravo", 0) << endl;*/
    //testParse();
    return 0;
}
