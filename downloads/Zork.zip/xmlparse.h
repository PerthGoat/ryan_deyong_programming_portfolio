#ifndef xmlparse_h
#define xmlparse_h

#include <cstdio>
#include <vector>
#include <cstdlib>
#include "datastructures.h"

void parseFile(FILE * file, vector<room> &rooms) {
    char c;
    string sb = ""; // our stringbuilder for working with the data
    string tag = ""; // holds the current tag we are operating on
    bool readflag = false;
    short readRequest = 0; // 1 is object, 2 is x coordinates, 3 is y coordinates, 4 is description
    bool newroom = false;
    room cur;
    while((c = fgetc(file)) != EOF) {
        //printf("%c", c);
        if(c == '<' && readflag) {
            //cout << sb << endl;
            switch(readRequest) { // switches based on what we want to read
                case 1: // looking to add an object to the floor
                    cur.addObjectToFloor(sb);
                break;
                case 2: // looking to add x coordinate for the room
                    short x;
                    x = atoi(sb.c_str());
                    cur.setXcoord(x);
                break;
                case 3: // looking to add y coordinate for the room
                    short y;
                    y = atoi(sb.c_str());
                    cur.setYcoord(y);
                break;
                case 4: // looking to add description to the room
                    cur.setDescription(sb);
                break;
                case 5: // looking to add an end room
                    short e;
                    e = atoi(sb.c_str());
                    cur.setEnd(e);
                break;
                case 6: // looking to add an end text string
                    cur.setEndText(sb);
                break;
                case 7: // looking to add a lock
                    short l;
                    l = atoi(sb.c_str());
                    cur.setLocked(l);
                break;
                case 8: // looking to add an object description
                    cur.addObjectDescription(sb);
                break;
            }
            readflag = false; // return back to xml parsing
        }
        
        //if(c != '\n')
        sb += c;
        
        if(c == '>') {
            tag = sb;
            // creates a new room if we fin dthe room tag
            if(tag.find("<room>") != string::npos) {
                rooms.push_back(cur);
                room temp;
                cur = temp;
            }
            if(tag.find("<xcoord>") != string::npos) {
                readflag = true;
                readRequest = 2;
            }
            if(tag.find("<ycoord>") != string::npos) {
                readflag = true;
                readRequest = 3;
            }
            if(tag.find("<description>") != string::npos) {
                readflag = true;
                readRequest = 4;
            }
            if(tag.find("<endroom>") != string::npos) {
                readflag = true;
                readRequest = 5; // requesting ending-define
            }
            if(tag.find("<endtext>") != string::npos) {
                readflag = true;
                readRequest = 6; // requesting end text-string
            }
            if(tag.find("<locked>") != string::npos) {
                readflag = true;
                readRequest = 7; // requesting a locked door
            }
            if(tag.find("<objectDesc>") != string::npos) {
                readflag = true;
                readRequest = 8; // requesting an object description
            }
            if(tag.find("<object>") != string::npos) {
                readflag = true;
                readRequest = 1;
                //cout << tag << endl;
            }
            //cout << tag << endl;
            sb = "";
        }
    }
    
    fclose(file);
    
    // removes the dummy room that exists for the code to work properly
    rooms.erase(rooms.begin());
    
    // adds the LAST room
    rooms.push_back(cur);
}


void testParse() {
    printf("Test\n");
}

#endif
