#ifndef datastructures_h
#define datastructures_h

#include <iostream>
#include <vector>
#include <string>

using namespace std;

class room {
    public:
        room() {
            endRoom = 0; // by default, a room is NOT the ending room
            locked = 0;
        }
        room(vector<string> s) { // constructor for easy debuggin
            objectsOnFloor = s;
        }
        
        // looks up an object based on which command is entered
        // cmd 0 = on the floor
        int lookup(string object, unsigned char cmd) {
            vector<string> toLookup;
            switch(cmd) {
                case 0:
                    toLookup = objectsOnFloor;
                break;
            }
            for(unsigned int i = 0;i < toLookup.size();i++) {
                //cout << toLookup[i] << "test";
                if(toLookup[i].find(object) != string::npos) { // a less strict lookup function to make code easier
                    return i;
                }
            }
            return -1; // means failure, could not find object
        }
        
        // gets an objects true name from the lookup since it can be different
        string getObjectName(string object) {
            return objectsOnFloor[lookup(object, 0)];
        }
        
        // adds a single object to the floor
        void addObjectToFloor(string object) {
            objectsOnFloor.push_back(object);
        }
        
        // removes an object from the floor by ID
        void removeObjectFromFloor(int objectID) {
            objectsOnFloor.erase(objectsOnFloor.begin() + objectID);
            objectDescriptions.erase(objectDescriptions.begin() + objectID);
        }
        
        // adds an object description
        void addObjectDescription(string desc) {
            objectDescriptions.push_back(desc);
        }
        
        // returns an object's description
        string readObjectDescription(int objectID) {
            return objectDescriptions[objectID];
        }
        
        // sets up setters for the xcoord and ycoord
        void setXcoord(short x) {
            xcoord = x;
        }
        
        void setYcoord(short y) {
            ycoord = y;
        }
        
        // gets for xcoord and ycoord
        short getXcoord() {
            return xcoord;
        }
        
        short getYcoord() {
            return ycoord;
        }
        
        // setter for description
        void setDescription(string s) {
            description = s;
        }
        
        // getter for description
        string getDescription() {
            return description;
        }
        
        // setters and getters for an endroom
        
        void setEnd(short e) {
            endRoom = e;
        }
        
        short getEnd() {
            return endRoom;
        }
        
        // setters and getters for endtext
        void setEndText(string e) {
            endtext = e;
        }
        
        string getEndText() {
            return endtext;
        }
        
        // setters and getters for locked
        void setLocked(short l) {
            locked = l;
        }
        
        short getLocked() {
            return locked;
        }
        
        // another debug function, disable in the final build?
        void printObjectsOnFloor() {
            for(unsigned int i = 0;i < objectsOnFloor.size();i++) {
                string object = objectsOnFloor[i];
                object = object.substr(0, object.find(":"));
                cout << object << endl;
            }
        }
        
        void printCoordinates() {
            cout << xcoord << " " << ycoord << endl;
        }
        
        void printDescription() {
            cout << description << endl;
        }
        
    private:
    vector<string> objectsOnFloor;
    vector<string> objectDescriptions;
    vector<short> actionableObjects;
    string description;
    string endtext;
    short xcoord, ycoord;
    short endRoom;
    short locked;
};

class player {
    public:
        player(short xpos, short ypos, vector<room> m) {
            xcoord = xpos;
            ycoord = ypos;
            map = m;
            findRoom();
        }
        
        // looks up an object from the inventory
        int lookup(string object) {
            for(unsigned int i = 0;i < inventory.size();i++) {
                if(inventory[i].find(object) != string::npos) {
                    return i;
                }
            }
            return -1; // means failure, could not find object
        }
        
        // checks if a particular room exists
        int roomExists(short x, short y) {
            int exists = 0;
            
            unsigned int i;
            
            for(i = 0;i < map.size();i++) {
                if(map[i].getXcoord() == x && map[i].getYcoord() == y) {
                    exists = 1;
                    break;
                    //return 1;
                }
            }
            
            if(exists == 1) {
                if(map[i].getLocked() >= 1) {
                    exists = 2;
                }
            }
            
            return exists;
        }
        
        // gets a room at the specified coordinates
        room getRoom(short x, short y) {
            room r;
            
            for(unsigned int i = 0;i < map.size();i++) {
                if(map[i].getXcoord() == x && map[i].getYcoord() == y) {
                    r = map[i];
                    break;
                }
            }
            return r;
        }
        
        // finds the current room the player is in
        void findRoom() {
            for(unsigned int i = 0;i < map.size();i++) {
                if(map[i].getXcoord() == xcoord && map[i].getYcoord() == ycoord) {
                    curroom = map[i];
                    return;
                }
            }
            throw logic_error("ERROR: Invalid Room; Out of bounds?");
        }
        
        // lists out the inventory
        void printInventory() {
            for(unsigned int i = 0;i < inventory.size();i++) {
                string object = inventory[i];
                object = object.substr(0, object.find(":"));
                cout << object << endl;
            }
        }
        
        // adds an object to the player inventory
        void addObjectToInventory(string obj) {
            inventory.push_back(obj);
        }
        
        // removes an object from the player inventory
        void removeObjectFromInventory(int objectID) {
            inventory.erase(inventory.begin() + objectID);
        }
        
        // picks up an object off the floor and puts it into the player inventory
        void pickupObject(string obj) {
            obj = curroom.getObjectName(obj); // gets the REAL name from a potential partial name
            if(obj.find(":ACT") == string::npos) { // if it's a designated action object, do not inventory it
                addObjectToInventory(obj);
                curroom.removeObjectFromFloor(curroom.lookup(obj, 0));
            }
            
            //printf("%d\n", curroom.lookup(obj, 0));
        }
        
        // gets an object's real name
        string getObjectName(string obj) {
            return inventory[lookup(obj)];
        }
        
        
        // move in a direction, 0 is north, 1 is east, 2 is south, 3 is west
        void move(char dir) {
            room r;
            
            short xc = xcoord;
            short yc = ycoord;
            
            switch(dir) {
                case 0: // north
                    yc = yc - 1;
                break;
                case 1: // east
                    xc = xc + 1;
                break;
                case 2: // south
                    yc = yc + 1;
                break;
                case 3: // west
                    xc = xc - 1;
                break;
            }
            
            switch(roomExists(xc, yc)) {
                case 1: // if it exists and is unlocked:
                    xcoord = xc;
                    ycoord = yc;
                break;
                case 2: // if it exists and is locked
                    printf("Door is locked and requires a key to be opened.\n");
                break;
                default:
                    printf("Tried to move into invalid room & %d %d\n", xc, yc);
                break;
            }
            // sets the current room after done moving
            findRoom();
        }
        
        void printCurrentRoom() {
            curroom.printDescription();
        }
        
        room getCurrentRoom() {
            return curroom;
        }
    private:
    room curroom;
    vector<room> map;
    vector<string> inventory;
    short xcoord, ycoord;
};

#endif