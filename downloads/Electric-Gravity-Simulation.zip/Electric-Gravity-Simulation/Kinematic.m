function [newx,newvx,newy,newvy]=Kinematic(oldx,oldy,vx,vy,Fx,Fy,m,dt)
ay=sum(Fy)/m;
ax=sum(Fx)/m;
newx=oldx+vx*dt+0.5*ax*dt^2;
newvx=vx+ax*dt;
newy=oldy+vy*dt+0.5*ay*dt^2;
newvy=vy+ay*dt;
end