% a function that simulates the particles based on GUI response
function [] = Simulate(hObject)
    % how long to pause for
    dt=0.1;
    % brings in the global p that holds all of the particles
    global p
    % brings in the global variables ELECTRIC and GRAVITY
    global ELECTRIC
    global GRAVITY
    % brings in the global variable SCALE that holds the scale we are
    % oprating in
    global SCALE
    % defines n
    n = length(p);
    % sets up collison checking
    %collide = 0;
    
    % checks if n is valid
    if n <= 1
        msgbox('ERROR: Must have 2 or greater particles to simulate');
        handles = guidata(hObject);
        set(handles.pushbutton1, 'String', 'Simulate');
        set(handles.pushbutton3, 'Enable', 'on');
        handles.simulateloop = 0;
        % Update handles structure
        guidata(hObject, handles);
        return;
    end
    
    % runs infinitely
    while(1)
        % simulation code goes here
        % simulate all of the particles gravity and electircal fields
        for k = 1:n-1
            for kk = k+1:n
               if(ELECTRIC)
                   [p(k).Fx(1),p(k).Fy(1),p(kk).Fx(1),p(kk).Fy(1)]=ElectricForces(p(k).q,...
                         p(kk).q,p(k).x,p(k).y,p(kk).x,p(kk).y,SCALE);
               end
               if(GRAVITY)
                   [p(k).Fx(2),p(k).Fy(2),p(kk).Fx(2),p(kk).Fy(2)]=GravityForces(p(k).m,...
                         p(kk).m,p(k).x,p(k).y,p(kk).x,p(kk).y,SCALE);
               end
%                if(collide)
%                    break;
%                end
               p(k).Fx(3)=sum(p(k).Fx);
               p(kk).Fx(3)=sum(p(kk).Fx);
               p(k).Fy(3)=sum(p(k).Fy);
               p(kk).Fy(3)=sum(p(kk).Fy);
            end
%             if(collide)
%                 break;
%             end
        end
%         if(collide)
%             break;
%         end
        % simulate kinematics of particles
        for k=1:n
            [newx(k),newvx(k),newy(k),newvy(k)]=Kinematic(p(k).x,p(k).y,p(k).vx,p(k).vy,...
                p(k).Fx(3),p(k).Fy(3),p(k).m,dt);
        end
        % update graph of all of the particles
        PlotParticles(p);
        % update velocities and coordinates
        for k=1:n
            p(k).vx=newvx(k);p(k).vy=newvy(k);
            p(k).x=newx(k);p(k).y=newy(k);
        end
        
        %disp(rand); %test stuff
        
        % gets the current GUI data
        handles = guidata(hObject);
        % if we should stop simulation, break out
        if(handles.simulateloop == 0)
            break;
        end
        % run-delay
        pause(dt);
    end
    
    % verification step, need to make sure that everything is ready to go
    % after we're done looping
%     if collide
%         handles = guidata(hObject);
%         set(handles.pushbutton1, 'String', 'Simulate');
%         handles.simulateloop = 0;
%         % Update handles structure
%         guidata(hObject, handles);
%         msgbox('Particle Collision');
%     end
end