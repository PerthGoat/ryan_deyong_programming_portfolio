function varargout = ConservativeForceSimulator(varargin)
% CONSERVATIVEFORCESIMULATOR MATLAB code for ConservativeForceSimulator.fig
%      CONSERVATIVEFORCESIMULATOR, by itself, creates a new CONSERVATIVEFORCESIMULATOR or raises the existing
%      singleton*.
%
%      H = CONSERVATIVEFORCESIMULATOR returns the handle to a new CONSERVATIVEFORCESIMULATOR or the handle to
%      the existing singleton*.
%
%      CONSERVATIVEFORCESIMULATOR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CONSERVATIVEFORCESIMULATOR.M with the given input arguments.
%
%      CONSERVATIVEFORCESIMULATOR('Property','Value',...) creates a new CONSERVATIVEFORCESIMULATOR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ConservativeForceSimulator_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ConservativeForceSimulator_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ConservativeForceSimulator

% Last Modified by GUIDE v2.5 12-Apr-2017 13:18:33

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ConservativeForceSimulator_OpeningFcn, ...
                   'gui_OutputFcn',  @ConservativeForceSimulator_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ConservativeForceSimulator is made visible.
function ConservativeForceSimulator_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ConservativeForceSimulator (see VARARGIN)

% Choose default command line output for ConservativeForceSimulator
handles.output = hObject;

% adds a variable in handles to keep track of simulation
handles.simulateloop = 0;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ConservativeForceSimulator wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% clears the global variable p on run
clear global p;

% sets up the global variables for ELECTRIC and GRAVITY defaults
global ELECTRIC
ELECTRIC = 0;
global GRAVITY
GRAVITY = 0;

% sets up global SCALE default
global SCALE
SCALE = 1;

% sets up the plot, including the axis, and drawing
axis([-10 10 -10 10]);
hold on;

% defines master plot
global MASTER
MASTER = handles.graph;


% --- Outputs from this function are returned to the command line.
function varargout = ConservativeForceSimulator_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1
global GRAVITY
GRAVITY = get(hObject, 'Value');


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2
global ELECTRIC
ELECTRIC = get(hObject, 'Value');

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.simulateloop == 1
    set(handles.pushbutton1, 'String', 'Simulate');
    set(handles.pushbutton3, 'Enable', 'on');
    set(handles.pushbutton2, 'Enable', 'on');
    handles.simulateloop = 0;
    % Update handles structure
    guidata(hObject, handles);
else
    set(handles.pushbutton1, 'String', 'Stop Simulate');
    set(handles.pushbutton3, 'Enable', 'off');
    set(handles.pushbutton2, 'Enable', 'off');
    handles.simulateloop = 1;
    % Update handles structure
    guidata(hObject, handles);
    Simulate(hObject);
end

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Particle_Properties(handles.graph);


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global SCALE

% Hint: get(hObject,'Value') returns toggle state of radiobutton1
if get(hObject, 'Value') == 1
    SCALE = 1;
end


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global SCALE

% Hint: get(hObject,'Value') returns toggle state of radiobutton2
if get(hObject, 'Value') == 1
    SCALE = 2;
end


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global SCALE

% Hint: get(hObject,'Value') returns toggle state of radiobutton3
if get(hObject, 'Value') == 1
    SCALE = 3;
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% clears everything so that it can be run again
global p
p = [];
cla;
