function []=PlotParticles(p)
% clears all of the current points off any plots
cla

% plots all of the points passed from the point structure
for k=1:length(p)
    a = plot(p(k).x,p(k).y,'o');
    set(a, 'Color', p(k).color);
end
end