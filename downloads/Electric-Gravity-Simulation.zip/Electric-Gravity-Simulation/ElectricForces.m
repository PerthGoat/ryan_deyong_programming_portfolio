function [force1x,force1y,force2x,force2y]=ElectricForces(charge1,charge2,...
    space1x,space1y,space2x,space2y,SCALE)
dx = space2x - space1x;
dy = space2y - space1y;

% electricity constant
E = 9e9;

if SCALE == 2
    E = E * (1.602e-9)^2 * (2.419e-17)^2/(1.66054e-27*1e-10);
elseif SCALE == 3
    E = E / (1.496e11)^2 * 31557600^2/(5.972e24*1.496e11);
end

r = sqrt(dx^2 + dy^2);

mstrength = (E * charge1 * charge2) / (r^2);

% force vector stuff
fv = [space2x - space1x, space2y - space1y];
fv = fv / norm(fv, Inf);

% final force
ff = fv * -mstrength;
force1x = ff(1);
force1y = ff(2);
force2x = -ff(1);
force2y = -ff(2);
end