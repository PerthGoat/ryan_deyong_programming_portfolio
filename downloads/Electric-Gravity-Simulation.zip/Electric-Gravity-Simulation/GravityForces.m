function [F1x,F1y,F2x,F2y]=GravityForces(m1,m2,p1x,p1y,p2x,p2y,SCALE)
dx = p2x - p1x;
dy = p2y - p1y;

G = 6.67428e-11;

if SCALE == 2
    G = G * (1.66054e-27/1e-10) ^ 2 * (2.419e-17)^2 / (1.66054e-27*1e-10);
elseif SCALE == 3
    G = G * (5.972e24/1.496e11)^2 * 31557600^2/(5.972e24*1.496e11);
end

r = sqrt(dx^2 + dy^2);

mstrength = (G * m1 * m2) / (r^2);

fv = [p2x - p1x, p2y - p1y];
% force vector
fv = fv / norm(fv, Inf);
% final force
ff = fv * mstrength;

F1x = ff(1);
F1y = ff(2);
F2x = -ff(1);
F2y = -ff(2);
end