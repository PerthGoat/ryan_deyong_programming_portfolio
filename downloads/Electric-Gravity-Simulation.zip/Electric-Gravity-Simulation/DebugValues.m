% usage: Run this script to debug all of the global values in the workspace

global ELECTRIC
global GRAVITY
global P