function [ collision ] = CollisionCheck( p1x, p1y, p2x, p2y )
%COLLISIONCHECK Detects if a collision has occurred between 2 particles
%   Returns collision
dx=p2x-p1x;dy=p2y-p1y;
r=sqrt(dy^2+dx^2);
if(r<0.4)
    collision=1;
else
    collision=0;
end

end

